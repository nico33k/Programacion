#29. Busca Internet qué función permite obtener la longitud de un String, realiza un programa que al introducir una frase devuelva la longitud
var = input('Introduce una frase: ')
print(len(var))