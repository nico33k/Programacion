#33. Programa un código que permita contar el número de vocales de la siguiente frase: No hay mal que dure cien años
txt = 'No hay mal que dure cien años'
a = txt.count('a')
e = txt.count('e')
i = txt.count('i')
o = txt.count('o')
u = txt.count('u')

print('El número de a es',a,' el número de e es',e,' el número de i es',i,' el número de o es',o,' y el número de u es',u)